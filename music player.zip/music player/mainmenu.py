# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'musicplayer.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# ARNING! All Wchanges made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from pygame import mixer
from library import Ui_librarymenu
from History import Ui_MenuHistori
import sqlite3
from mutagen.mp3 import MP3
import os
from Help import Ui_HelpWindow
import threading
import time
import multiprocessing
import sys




class Ui_MainMenu(QtWidgets.QDialog):
    number=0
    running=False
    musictime=0
    musiclist=[]
    playcondition="stop"
    previousmusic=""
    volume=1.0
    




    def setupUi(self, MainMenu):
        MainMenu.setObjectName("MainMenu")
        MainMenu.setEnabled(True)
        MainMenu.resize(427, 268)
        MainMenu.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        MainMenu.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(209, 147, 57, 255), stop:1 rgba(255, 255, 255, 255));")
        self.centralwidget = QtWidgets.QWidget(MainMenu)
        self.centralwidget.setObjectName("centralwidget")
        self.btnnext = QtWidgets.QPushButton(self.centralwidget)
        self.btnnext.setGeometry(QtCore.QRect(260, 200, 41, 23))
        self.btnnext.setMinimumSize(QtCore.QSize(41, 23))
        self.btnnext.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(r"002-next.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnnext.setIcon(icon)
        self.btnnext.setObjectName("btnnext")
        self.bntlibrary=QtWidgets.QPushButton(self.centralwidget)
        self.bntlibrary.setObjectName("btnlibrary")
        self.bntlibrary.setText("Library")
        self.btnHistory=QtWidgets.QPushButton(self.centralwidget)
        self.btnHistory.setObjectName("btnHistori")
        self.btnHistory.setText("History")
        self.btnHistory.move(70,0)

        self.btnhelp=QtWidgets.QPushButton(self.centralwidget)
        self.btnhelp.setObjectName("btnHelp")
        self.btnhelp.setText("Help")
        self.btnhelp.move(140,0)
       

        self.btnplay = QtWidgets.QPushButton(self.centralwidget)
        self.btnplay.setGeometry(QtCore.QRect(220, 200, 41, 23))
        self.btnplay.setMinimumSize(QtCore.QSize(41, 23))
        self.btnplay.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(r"003-play-button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnplay.setIcon(icon1)
        self.btnplay.setObjectName("btnplay")
        self.btnprevious = QtWidgets.QPushButton(self.centralwidget)
        self.btnprevious.setGeometry(QtCore.QRect(180, 200, 41, 23))
        self.btnprevious.setMinimumSize(QtCore.QSize(41, 23))
        self.btnprevious.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("001-previous-4.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnprevious.setIcon(icon2)
        self.btnprevious.setObjectName("btnprevious")
        self.btnvolumedown = QtWidgets.QPushButton(self.centralwidget)
        self.btnvolumedown.setGeometry(QtCore.QRect(350, 200, 20, 23))
        self.btnvolumedown.setText("")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(r"008-left-arrow.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnvolumedown.setIcon(icon3)
        self.btnvolumedown.setObjectName("btnvolumedown")
        self.btnvolumeup = QtWidgets.QPushButton(self.centralwidget)
        self.btnvolumeup.setGeometry(QtCore.QRect(390, 200, 21, 23))
        self.btnvolumeup.setText("")
        self.lbltime=QtWidgets.QLabel(self.centralwidget)
        self.lbltime.setText(" 0  ")
        self.lbltime.move(60,207)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(r"001-right-arrow-4.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnvolumeup.setIcon(icon4)
        self.btnvolumeup.setObjectName("btnvolumeup")
        self.slidermusic = QtWidgets.QSlider(self.centralwidget)
        self.slidermusic.setGeometry(QtCore.QRect(60, 180, 351, 22))
        self.slidermusic.setOrientation(QtCore.Qt.Horizontal)
        self.slidermusic.setObjectName("slidermusic")
        mixer.init()
        self.slidermusic.setRange(0,100)
        self.slidermusic.setValue(int(mixer.music.get_pos()))

        
        self.btnsound = QtWidgets.QPushButton(self.centralwidget)
        self.btnsound.setGeometry(QtCore.QRect(370, 200, 20, 23))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.btnsound.setFont(font)
        self.btnsound.setText("")
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap(r"015-volume-adjustment.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnsound.setIcon(icon5)
        self.btnsound.setObjectName("btnsound")
        self.btnstop = QtWidgets.QPushButton(self.centralwidget)
        self.btnstop.setGeometry(QtCore.QRect(144, 200, 41, 23))
        self.btnstop.setMinimumSize(QtCore.QSize(41, 23))
        self.btnstop.setText("")
        icon6 = QtGui.QIcon()
        icon6.addPixmap(QtGui.QPixmap(r"stop.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnstop.setIcon(icon6)
        self.btnstop.setObjectName("btnstop")
        self.btnsearchmusic = QtWidgets.QPushButton(self.centralwidget)
        self.btnsearchmusic.setGeometry(QtCore.QRect(110, 200, 41, 23))
        self.btnsearchmusic.setMinimumSize(QtCore.QSize(41, 23))
        self.btnsearchmusic.setText("")
        self.btnrepeat = QtWidgets.QPushButton(self.centralwidget)
        self.btnrepeat.setGeometry(QtCore.QRect(84, 200, 31, 23))
        self.btnrepeat.setText("")
        icon8 = QtGui.QIcon()
        icon8.addPixmap(QtGui.QPixmap(r"004-music-player.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnrepeat.setIcon(icon8)
        self.btnrepeat.setObjectName("btnrepeat")
        icon7 = QtGui.QIcon()
        icon7.addPixmap(QtGui.QPixmap(r"002-eject.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnsearchmusic.setIcon(icon7)
        self.btnsearchmusic.setObjectName("btnsearchmusic")
        MainMenu.setCentralWidget(self.centralwidget)
    
        self.txtmusicname = QtWidgets.QLineEdit(self.centralwidget)
        self.txtmusicname.setGeometry(QtCore.QRect(60, 30, 341, 20))
        self.txtmusicname.setEchoMode(QtWidgets.QLineEdit.Normal)
        self.txtmusicname.setObjectName("txtmusicname")
        self.txtmusicname.setEnabled(False)
        self.retranslateUi(MainMenu)
        QtCore.QMetaObject.connectSlotsByName(MainMenu)
        self.clickevent()
        self.t=threading.Thread(target=self.showmusictime)
        
            
        

    def retranslateUi(self, MainMenu):
        _translate = QtCore.QCoreApplication.translate
        MainMenu.setWindowTitle(_translate("MainMenu", "Music Player"))

    def showHelpMenu(self):
        self.Helpmenu=QtWidgets.QMainWindow()
        self.helpUi=Ui_HelpWindow()
        self.helpUi.setupUi(self.Helpmenu)
        self.Helpmenu.show()


    def showLibraryMenu(self):
        self.librarymenu = QtWidgets.QMainWindow()
        self.ui = Ui_librarymenu()
        self.ui.setupUi(self.librarymenu)
        self.librarymenu.show()   
        self.ui.btnaddtolist.clicked.connect(self.browserforlibrary)
        self.addtolibrarytable(self.musiclist)
        self.ui.btnremove.clicked.connect(self.removefromlibrary)
        self.ui.btnbacktomenu.clicked.connect(self.librarymenu.close)
        self.ui.btnplaylist.clicked.connect(self.playlibrarylist)

    def showHistoryMenu(self):
        self.historymenu=QtWidgets.QMainWindow()
        self.historyui=Ui_MenuHistori()
        self.historyui.setupUi(self.historymenu)
        self.historymenu.show()
        self.historyui.showrecentmusics()
        self.historyui.txtsearchmusic.textChanged.connect(self.historyui.searchmusic)
        self.historyui.btnBack.clicked.connect(self.historymenu.close)
        self.historyui.btnplayhistory.clicked.connect(self.playmusicfromhistory)
        self.historyui.btnremove.clicked.connect(self.historyui.removemusicfromhistory)


    def playlibrarylist(self):
        if len(self.musiclist) !=0:
            mixer.init()
            mixer.music.stop()
            self.playcondition="stop"
            musicname=self.musiclist[self.number][0]
            self.txtmusicname.setText(musicname)
            self.playmusic()

    def playpreviousmusic(self):
        if self.number != 0:
            mixer.init()
            mixer.music.stop()
            self.playcondition="stop"
            self.number=self.number - 1
            musicname=self.musiclist[self.number][0]
            self.txtmusicname.setText(musicname)
            self.playmusic()


    def playnextmusic(self):
        if len(self.musiclist) >= self.number + 2:
            mixer.init()
            mixer.music.stop()
            self.playcondition="stop"
            self.musictime=0
            self.lbltime.setText(str(0))
            self.number=self.number +1
            musicname=self.musiclist[self.number][0]
            self.txtmusicname.setText(musicname)
            self.playmusic()


    def removefromlibrary(self):
        if len(self.musiclist) !=0:
            currentRow=self.ui.tableWidgetmusic.currentRow()
            musicname=self.ui.tableWidgetmusic.item(currentRow,0).text()
            length=self.getlength1(musicname,"min")
            self.musiclist.remove([musicname,length])
            self.addtolibrarytable(self.musiclist)

        

    def addtolibrarytable(self,musiclist):
        self.ui.tableWidgetmusic.setRowCount(0)
        for rows in range(0,len(self.musiclist)):
            self.ui.tableWidgetmusic.setRowCount(rows+1)
            self.ui.tableWidgetmusic.setItem(rows,0,QtWidgets.QTableWidgetItem(musiclist[rows][0]))
            self.ui.tableWidgetmusic.setItem(rows,1,QtWidgets.QTableWidgetItem(musiclist[rows][1]))


    def getlength1(self,musicname,format):
        if format=="second":
            music=MP3(musicname)
            length=int(music.info.length)
            return length

        elif format=="min":

            music=MP3(musicname)
            length=int(music.info.length)
            min=int(length/60)
            sec= int(length-(min*60))
            return str(min)+":" + str(sec)  

    

    def browserforlibrary(self):
        musicname=QtWidgets.QFileDialog.getOpenFileName(self,"Select Music","C:\\","MP3 Files(*.mp3)")  
        length="unknown"
        if musicname[0] !="":
            length=self.getlength1(musicname[0],"min")
            self.musiclist.append([musicname[0],length])
            self.addtolibrarytable(self.musiclist)

    def playmusicfromhistory(self):
        currentrow=self.historyui.tableWidget.currentRow()
        musicname=self.historyui.tableWidget.item(currentrow,0).text()
        if os.path.isfile(musicname):
            mixer.init()
            if mixer.music.get_busy():
                mixer.music.stop()
                self.txtmusicname.setText(musicname)
                self.playcondition="stop"
                self.running=False
                self.musictime=0
                self.running=True
                self.playmusic()
                self.playcondition="play"
            else:
                self.txtmusicname.setText(musicname)
                self.playcondition="stop"
                self.musictime=0
                self.playmusic()
                self.playcondition="play"
                



    def clickevent(self):
        self.btnsearchmusic.clicked.connect(self.browserclick)
        self.btnplay.clicked.connect(self.playmusic)
        self.btnstop.clicked.connect(self.stopmusic)  
        self.btnrepeat.clicked.connect(self.repeatmusic)
        self.btnvolumedown.clicked.connect(self.volumedown)
        self.btnvolumeup.clicked.connect(self.volumeup)
        self.bntlibrary.clicked.connect(self.showLibraryMenu)
        self.btnHistory.clicked.connect(self.showHistoryMenu) 
        self.btnhelp.clicked.connect(self.showHelpMenu)
        self.btnnext.clicked.connect(self.playnextmusic)
        self.btnprevious.clicked.connect(self.playpreviousmusic)
        
        


    def slidervaluechange(self):
        mixer.init()
        position=self.slidermusic.value()
        mixer.music.set_pos(position * 1000)
        self.musictime=int(position)




    def showmusictime(self):
        if self.running==False:
            return
        
        mixer.init()
        music=MP3(self.txtmusicname.text())
        duration=int(music.info.length)
        if self.musictime==duration :
            mixer.music.stop()
            icon6=QtGui.QIcon()
            icon6.addPixmap(QtGui.QPixmap(r"003-play-button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.btnplay.setIcon(icon6)
            self.playcondition="stop"
            if len(self.musiclist) >self.number+1:
                self.number=self.number+1
                self.txtmusicname.setText(self.musiclist[self.number][0])
                self.musictime=0
                self.slidermusic.setValue(0)
                self.lbltime.setText(str(0))
                self.playmusic()


        if self.playcondition=="play" and self.musictime != duration :
            self.lbltime.setText(str(self.musictime))
            time.sleep(1)
            self.musictime=self.musictime + 1
            self.slidermusic.setValue(self.musictime)
            self.showmusictime()

        elif self.playcondition=="pause":
            return

        elif self.playcondition=="stop":
            self.slidermusic.setValue(0)
            self.musictime=0
            self.lbltime.setText(str(self.musictime))
            return



            
            



    def playmusic(self):
        import copy
        musicname=""
        mixer.init()
        musicname=self.txtmusicname.text()
        if mixer.music.get_busy():
            if self.playcondition=="play":
                icon11 = QtGui.QIcon()
                mixer.music.pause()
                icon11.addPixmap(QtGui.QPixmap(r"003-play-button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                self.btnplay.setIcon(icon11)
                self.playcondition="pause"
                self.running=False
                


            elif self.playcondition=="pause":
                mixer.music.unpause()
                icon12 = QtGui.QIcon()
                icon12.addPixmap(QtGui.QPixmap(r"010-pause-2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                self.btnplay.setIcon(icon12)
                self.playcondition="play"
                self.running=True
        
        else :
            if len(musicname) != 0:
                
                mixer.music.load(musicname)
                mixer.music.play()
                icon16 = QtGui.QIcon()
                icon16.addPixmap(QtGui.QPixmap(r"010-pause-2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
                self.btnplay.setIcon(icon16)
                self.playcondition="play"
                self.musictime=0
                self.slidermusic.setValue(0)
                self.lbltime.setText('0')
                self.running=True
                self.AddMusicToHistory()

        if len(self.txtmusicname.text()) != 0  and self.playcondition !="pause":
            duration=self.getlength1(self.txtmusicname.text(),"second")
            self.slidermusic.setRange(0,duration)
            
            x=threading.active_count()
            if x>1:
                return

            else:
                t=threading.Thread(target=self.showmusictime,daemon=True)
                t.start()
            
        
        

    
        




    def getlength(self):
        musicname=self.txtmusicname.text()
        music=MP3(musicname)
        length=int(music.info.length)
        min=int(length/60)
        sec=length-(min*60)
        return str(min)+":" + str(sec)

    

    def AddMusicToHistory(self):
        import time
        present=time.ctime()
        musicname=self.txtmusicname.text()
        length="unknown"
        musicformat=os.path.splitext(musicname)
        if musicformat[1]==".mp3":
            length=self.getlength()
        sc=sqlite3.connect(r"musicplayer.db")
        cursor=sc.cursor()
        query="""insert into History  values(?,?,?)"""
        data_tuple=(musicname,length,present,)
        cursor.execute(query,data_tuple)
        sc.commit()
        cursor.close()
        sc.close()


    def repeatmusic(self):
        musicname=self.txtmusicname.text()
        if len(musicname) != 0 and self.playcondition=="play":
            mixer.init()
            mixer.music.stop()
            self.playcondition="stop"
            self.playmusic()
                      
            
        
            



    def stopmusic(self):
        mixer.init()
        if  mixer.music.get_busy:
            mixer.init()
            icon13 = QtGui.QIcon()
            icon13.addPixmap(QtGui.QPixmap(r"003-play-button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.btnplay.setIcon(icon13)
            self.playcondition="stop"           
            mixer.music.stop()
            
            self.musictime=0

    
    def browserclick(self):
        musicname=QtWidgets.QFileDialog.getOpenFileName(self,"Select Music","C:\\","MP3 Files(*.mp3)")
        if musicname[0] != "" :
            
            icon15 = QtGui.QIcon()
            icon15.addPixmap(QtGui.QPixmap(r"010-pause-2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
            self.btnplay.setIcon(icon15)
            mixer.init()
            mixer.music.stop()
            self.playcondition="stop"
            self.txtmusicname.setText(musicname[0])
            self.playmusic()
            
            self.musictime=0
            self.running=True
            duration=self.getlength1(self.txtmusicname.text(),"second")
            self.slidermusic.setRange(0,duration)
            
            
            
        
            
            
            
    def volumeup(self):
        mixer.init()
        sound=mixer.music.get_volume()
        if sound != 1.0:
            mixer.music.set_volume(sound + 0.1)
            self.volume=sound + 0.1

    def volumedown(self):
        sound=mixer.music.get_volume()
        if sound != 0.0:
            mixer.music.set_volume(sound - 0.1)
            self.volume=sound - 0.1
    
    


if __name__ == "__main__":
    import sys
    import os
    app = QtWidgets.QApplication(sys.argv)
    MainMenu = QtWidgets.QMainWindow()
    librarymenu=QtWidgets.QMainWindow()
    ui = Ui_MainMenu()
    ui.setupUi(MainMenu)
    MainMenu.show()
    sys.exit(app.exec_())
