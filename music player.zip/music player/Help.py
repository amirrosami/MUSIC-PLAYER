# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Help.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_HelpWindow(object):
    def setupUi(self, HelpWindow):
        HelpWindow.setObjectName("HelpWindow")
        HelpWindow.resize(574, 459)
        HelpWindow.setLayoutDirection(QtCore.Qt.RightToLeft)
        HelpWindow.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(209, 147, 57, 255), stop:1 rgba(255, 255, 255, 255));")
        self.centralwidget = QtWidgets.QWidget(HelpWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(0, 30, 571, 121))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.groupBox.setFont(font)
        self.groupBox.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.groupBox.setObjectName("groupBox")
        self.txtproducers = QtWidgets.QTextEdit(self.groupBox)
        self.txtproducers.setGeometry(QtCore.QRect(10, 20, 561, 91))
        font = QtGui.QFont()
        font.setFamily("Arial Rounded MT Bold")
        font.setPointSize(16)
        self.txtproducers.setFont(font)
        self.txtproducers.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.txtproducers.setObjectName("txtproducers")
        self.txtproducers.setText("Amir Hossein Rostami\n\nAmirreza Shahverdi")
        self.txtproducers.setEnabled(False)
        self.groupBox_2 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox_2.setGeometry(QtCore.QRect(0, 159, 571, 291))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.groupBox_2.setFont(font)
        self.groupBox_2.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.groupBox_2.setObjectName("groupBox_2")
        self.txtaboutApp = QtWidgets.QTextEdit(self.groupBox_2)
        self.txtaboutApp.setGeometry(QtCore.QRect(3, 30, 571, 251))
        self.txtaboutApp.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.txtaboutApp.setObjectName("txtaboutApp")
        self.txtaboutApp.setFont(font)
        self.txtaboutApp.setText("a music player is a program that can play and manage songs.\n\nthis program is for windows operating systems and you can play your mp3 songs")
        self.txtaboutApp.setEnabled(False)
        HelpWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(HelpWindow)
        self.statusbar.setObjectName("statusbar")
        HelpWindow.setStatusBar(self.statusbar)

        self.retranslateUi(HelpWindow)
        QtCore.QMetaObject.connectSlotsByName(HelpWindow)

    def retranslateUi(self, HelpWindow):
        _translate = QtCore.QCoreApplication.translate
        HelpWindow.setWindowTitle(_translate("HelpWindow", "Help"))
        self.groupBox.setTitle(_translate("HelpWindow", "Producers    "))
        self.groupBox_2.setTitle(_translate("HelpWindow", "About App"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    HelpWindow = QtWidgets.QMainWindow()
    ui = Ui_HelpWindow()
    ui.setupUi(HelpWindow)
    HelpWindow.show()
    sys.exit(app.exec_())
