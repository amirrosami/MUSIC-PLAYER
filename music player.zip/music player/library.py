# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'library.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from mutagen.mp3 import MP3


class Ui_librarymenu(QtWidgets.QDialog):

    def setupUi(self, librarymenu):
        librarymenu.setObjectName("librarymenu")
        librarymenu.resize(471, 350)
        librarymenu.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(209, 147, 57, 255), stop:1 rgba(255, 255, 255, 255));")
        self.centralwidget = QtWidgets.QWidget(librarymenu)
        self.centralwidget.setObjectName("centralwidget")
        self.tableWidgetmusic = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidgetmusic.setGeometry(QtCore.QRect(0, 60, 471, 241))
        self.tableWidgetmusic.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.tableWidgetmusic.setFrameShadow(QtWidgets.QFrame.Plain)
        self.tableWidgetmusic.setLineWidth(1)
        self.tableWidgetmusic.setAlternatingRowColors(False)
        self.tableWidgetmusic.setRowCount(0)
        self.tableWidgetmusic.setColumnCount(2)
        self.tableWidgetmusic.setObjectName("tableWidgetmusic")
        item = QtWidgets.QTableWidgetItem()
        self.tableWidgetmusic.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidgetmusic.setHorizontalHeaderItem(1, item)
        self.tableWidgetmusic.horizontalHeader().setVisible(True)
        self.tableWidgetmusic.horizontalHeader().setCascadingSectionResizes(True)
        self.tableWidgetmusic.horizontalHeader().setDefaultSectionSize(235)
        self.tableWidgetmusic.horizontalHeader().setHighlightSections(True)
        self.tableWidgetmusic.horizontalHeader().setMinimumSectionSize(40)
        self.tableWidgetmusic.verticalHeader().setDefaultSectionSize(24)
        self.searchmusic = QtWidgets.QLineEdit(self.centralwidget)
        self.searchmusic.setGeometry(QtCore.QRect(150, 40, 281, 21))
        self.searchmusic.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.searchmusic.setText("")
        self.searchmusic.setFrame(True)
        self.searchmusic.setDragEnabled(False)
        self.searchmusic.setReadOnly(False)
        self.searchmusic.setPlaceholderText("")
        self.searchmusic.setObjectName("searchmusic")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(430, 40, 51, 21))
        self.label.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("001-search.png"))
        self.label.setObjectName("label")
        self.btnaddtolist = QtWidgets.QPushButton(self.centralwidget)
        self.btnaddtolist.setGeometry(QtCore.QRect(100, 40, 51, 21))
        font = QtGui.QFont()
        font.setPointSize(8)
        self.btnaddtolist.setFont(font)
        self.btnaddtolist.setObjectName("pushButton")
        self.btnremove = QtWidgets.QPushButton(self.centralwidget)
        self.btnremove.setGeometry(QtCore.QRect(50, 40, 51, 21))
        self.btnremove.setObjectName("pushButton_2")
        self.btnplaylist = QtWidgets.QPushButton(self.centralwidget)
        self.btnplaylist.setGeometry(QtCore.QRect(0, 40, 51, 21))
        self.btnplaylist.setObjectName("pushButton_3")
        self.btnbacktomenu=QtWidgets.QPushButton(self.centralwidget)
        self.btnbacktomenu.setText("Back")
        
        librarymenu.setCentralWidget(self.centralwidget)
        
        

        self.retranslateUi(librarymenu)
        QtCore.QMetaObject.connectSlotsByName(librarymenu)

    def retranslateUi(self, librarymenu):
        _translate = QtCore.QCoreApplication.translate
        librarymenu.setWindowTitle(_translate("librarymenu", "Library"))
        item = self.tableWidgetmusic.horizontalHeaderItem(0)
        item.setText(_translate("librarymenu", "Music Name"))
        item = self.tableWidgetmusic.horizontalHeaderItem(1)
        item.setText(_translate("librarymenu", "Duration"))
        self.btnaddtolist.setText(_translate("librarymenu", "Add"))
        self.btnremove.setText(_translate("librarymenu", "remove"))
        self.btnplaylist.setText(_translate("librarymenu", "Play List"))

   

   

def showlibrarymenu():
    if __name__ == "__main__":
        import sys
        app = QtWidgets.QApplication(sys.argv)
        librarymenu = QtWidgets.QMainWindow()
        ui = Ui_librarymenu()
        ui.setupUi(librarymenu)
        librarymenu.show()
        sys.exit(app.exec_())
